//
//  ViewController.m
//  CocoapodsSample
//
//  Created by Stéphane ADAM-GARNIER on 16/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"

@implementation ViewController

@synthesize results = _results;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //create a simple table view and add it as the main view for this view controller
    tableViewVue = [[UITableView alloc] init];
    tableViewVue.backgroundColor = [UIColor colorWithRed:0.96 green:0.95 blue:0.90 alpha:1.0];
    tableViewVue.delegate = self;
    tableViewVue.dataSource = self;
    
    self.view = tableViewVue;
    
    
    
    // AFNetworking in action
    NSURL *url = [NSURL URLWithString:@"http://search.twitter.com/search.json?q=iphone"]; // marche correctement
    //NSURL *url = [NSURL URLWithString:@"http://stephaneadamgarnier.com/WORDPRESSJQUERYMOBILE/post_app_wp_ljson_linker.php?get_wp_posts_json"]; // error
    //NSURL *url = [NSURL URLWithString:@"http://stephaneadamgarnier.com/porpoise/config/GeolocsForRowsJSON.php?realJSON"]; // error (same > must be resulting from the use of "custom API calls")
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    AFJSONRequestOperation *operation;
    operation = [AFJSONRequestOperation JSONRequestOperationWithRequest:request
                                                               success:^(NSURLRequest *req, NSHTTPURLResponse *response, id jsonObject) {
                                                                   NSLog(@"Response: %@", jsonObject);
                                                                   //pulling out the "result" key from twitter (>yup, it's an array)
                                                                   self.results = [jsonObject objectForKey:@"results"];
                                                                   [tableViewVue reloadData];
                                                               } 
                                                               failure:^(NSURLRequest *req, NSHTTPURLResponse *response, NSError *error, id jsonObject) {
                                                                   NSLog(@"Received an HTTP %d", response.statusCode);
                                                                   NSLog(@"The error was: %@", error);
                                                               }];
    [operation start];
    
    
    //self.view.backgroundColor = [UIColor greenColor];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [tableViewVue release];
    tableViewVue = nil;
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

#pragma mark UITableViewDelegate / UITableViewDataSource methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{   
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.results.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] autorelease];
        cell.contentView.backgroundColor = tableView.backgroundColor;
        cell.textLabel.font = [UIFont boldSystemFontOfSize:14];
        cell.textLabel.textColor = [UIColor darkGrayColor];
        cell.textLabel.backgroundColor = cell.contentView.backgroundColor;
        cell.detailTextLabel.backgroundColor = cell.textLabel.backgroundColor;
    }
    
    //pull out that tweet (wich is gonna be a dictionnary)
    NSDictionary *tweet = [self.results objectAtIndex:indexPath.row];
    //and then check the things we are interested in
    // author / text / profile image
    
    cell.textLabel.text = [tweet objectForKey:@"from_user_name"];
    NSLog(@"user name: %@", cell.textLabel.text);
    cell.detailTextLabel.text = [tweet objectForKey:@"text"];
    
    //cell.textLabel.text = [NSString stringWithFormat:@"Cell %d", indexPath.row];
    
    return cell;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
