//
//  ViewController.h
//  CocoapodsSample
//
//  Created by Stéphane ADAM-GARNIER on 16/05/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    UITableView *tableViewVue;
}

@property (nonatomic, retain) NSArray *results;

@end
